self.assetsManifest = {
  "version": "wZh+XyIj",
  "assets": [
    {
      "hash": "sha256-VwR+nFJnPWZsgH4Wx4ZS7z28MKidBPfD7ySTjXWcUNU=",
      "url": "PruebaNetlify.styles.css"
    },
    {
      "hash": "sha256-Wow92XrctX9ATGksbBy69cxvhHgekdo/RmRfhUZUYIQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.mpwfhul8dx.wasm"
    },
    {
      "hash": "sha256-27kRe5fIcpy7UrkWBK3TWlnYdtwAWOJnhJPWKkGnpI0=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.58wgnqu1mi.wasm"
    },
    {
      "hash": "sha256-tOndDFoqyWBQQkT7eD1T5DyVAQnpHm/rW242PtoFeac=",
      "url": "_framework/Microsoft.AspNetCore.Components.oblf8ulxko.wasm"
    },
    {
      "hash": "sha256-EScOvyLYbGHyXzhFvrjRm2JZrZ6rIDhmUXRvPgDTopY=",
      "url": "_framework/Microsoft.Extensions.Configuration.33kpvunugc.wasm"
    },
    {
      "hash": "sha256-if+LK/X2QiubYZTpryZvRrMyTu2U2TFOuAkbwh3zGOA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vydvg25cgq.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-o3DZ22g4zto3RmLtosapeKSFHJzL3VXoNJfcMmtGWGk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3snpc8ocur.wasm"
    },
    {
      "hash": "sha256-6L7CjrgYaBlLrY1KbpMXd+mp0EP6ZR6E20iiqskGQes=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.c3j5ni1jcy.wasm"
    },
    {
      "hash": "sha256-r3ALIvSOk0g4dgtBLA1dskSc4tr0FbV4GBi9KLaLyhQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3z07kbhr47.wasm"
    },
    {
      "hash": "sha256-2o41anbTbxpSDCdgiXgltHqZusjWuT1+M9amuIjDsAM=",
      "url": "_framework/Microsoft.Extensions.Logging.efb40z18hz.wasm"
    },
    {
      "hash": "sha256-ZWvLi4uD1DhpugB3wdKLcFn2yjTRZKmZhg7SRHhNgxE=",
      "url": "_framework/Microsoft.Extensions.Options.hpxn5zhjfy.wasm"
    },
    {
      "hash": "sha256-kHdBFA5OWOMEPY2Az5SW/Fua4Wmqv8F6pKmiIpg6VSE=",
      "url": "_framework/Microsoft.Extensions.Primitives.cpcl4kfg57.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-rRq61G5+VpvRhc2RdIUOJdMTUibtZislv30ocJcRdV0=",
      "url": "_framework/Microsoft.JSInterop.betqyv1awt.wasm"
    },
    {
      "hash": "sha256-fpFxtighCDGfucw7eGig6ZUttHmlcbxCuE/H741A6q4=",
      "url": "_framework/PruebaNetlify.y4hbr6brcg.wasm"
    },
    {
      "hash": "sha256-qKVZ042E50xBcV3ggaHXb2KZtWW96xdU+lcNmqUzw6o=",
      "url": "_framework/System.Collections.Concurrent.0u78ckf640.wasm"
    },
    {
      "hash": "sha256-cgMZBT1i/bRYFDDMml6KDHkxsTvWgPi2gBFFCHMDWE4=",
      "url": "_framework/System.Collections.Immutable.q6k5qdu67c.wasm"
    },
    {
      "hash": "sha256-c6JTOZclFNJKABzHSgnvLWQMzMxfLKbdyyjtw/mBaV0=",
      "url": "_framework/System.Collections.flv6pt78m6.wasm"
    },
    {
      "hash": "sha256-j4xVR2d1tpwZrUoag5ugeqAMDDfGXlE9q1rpeRzeLQY=",
      "url": "_framework/System.ComponentModel.zvpmoupymb.wasm"
    },
    {
      "hash": "sha256-6AnyLxWZDomxYGjL7oey+e9wYELwNH4b+VvbA5hrK/Q=",
      "url": "_framework/System.Console.4xbni2kq7l.wasm"
    },
    {
      "hash": "sha256-rJVTcydznDq5HMdT7Z67I3xbhQMfUlB/S4Pev2arlb4=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ojhazo1uyi.wasm"
    },
    {
      "hash": "sha256-U40nDmWhvki2ysl5ZN4nXTJ/25f2Owz3e9BIBOqLS1Y=",
      "url": "_framework/System.IO.Pipelines.5ujx8ulk75.wasm"
    },
    {
      "hash": "sha256-S8ku9+9bOySGqDlfmUiq8xD5d6AoQ2+ZF7qojiKpaUQ=",
      "url": "_framework/System.Linq.d6xr2hjsog.wasm"
    },
    {
      "hash": "sha256-8QuQlI+GDyWHcN0FjzMvQGAyvJDUV+uMf2ELfyaLsdI=",
      "url": "_framework/System.Memory.j3p0152ymq.wasm"
    },
    {
      "hash": "sha256-5lhQJk4oa1fl7yXO9Fyhr27dWjxyjJ1bn4LPf4GnL7E=",
      "url": "_framework/System.Net.Http.Json.ejqnth2elm.wasm"
    },
    {
      "hash": "sha256-WxQnukVmvmRn+CUAxormHxbXcBMQEz6i/hx3bq9fT6Q=",
      "url": "_framework/System.Net.Http.frcvi03lfn.wasm"
    },
    {
      "hash": "sha256-RrAqmAHohERJK6ltedHgbZj7mMAwwgWxs4hS92FGJDM=",
      "url": "_framework/System.Net.Primitives.aficcbn7zu.wasm"
    },
    {
      "hash": "sha256-+ZZYXKl6l9vz1mzFmxUS5GtRdTbB1tJODujdzKtUxqE=",
      "url": "_framework/System.Private.CoreLib.rryk8975b8.wasm"
    },
    {
      "hash": "sha256-DPf7PG7tj0tFxPJ8Tj6oM2ulCrpGOLbQTFhV1LIebro=",
      "url": "_framework/System.Private.Uri.ssct5j4qy3.wasm"
    },
    {
      "hash": "sha256-jj+hXeHxXtNJ/yFTBFkWF83+YlrVlIlndehUiym2PoQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.yzg2xf6fe9.wasm"
    },
    {
      "hash": "sha256-0MaV28jOT/lN5xJJ1PcubKQM0zb6tgo30U8CZjR//1A=",
      "url": "_framework/System.Runtime.gctdtpz2vk.wasm"
    },
    {
      "hash": "sha256-E04MD5+M8yUnUB3bCz1aqecOvGzLKoWYaMzJ+vxfHro=",
      "url": "_framework/System.Security.Cryptography.js9a235qw5.wasm"
    },
    {
      "hash": "sha256-AA6jOaoPm5oQo0W0l4fYCa12tq3b1ZPDVZBQvrZ9658=",
      "url": "_framework/System.Text.Encodings.Web.oyio8sakfa.wasm"
    },
    {
      "hash": "sha256-D3qC6l8RR+C07WAZqEnsiM2x/7ICdH2VQPy48qBUm+E=",
      "url": "_framework/System.Text.Json.txjceamkff.wasm"
    },
    {
      "hash": "sha256-VgY1lDP3aBBNSxOfQNYIJ/TzmvcdDCYDUcUTJTMZNiQ=",
      "url": "_framework/System.Text.RegularExpressions.2d455bbq8f.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-1hiHAUXIAmD/UQpIXYbFYy8l24JSscOR/KQBLdyW/mE=",
      "url": "_framework/dotnet.asfpvbg1k5.js"
    },
    {
      "hash": "sha256-zE11fbcG2CeLl1Zi+NJgMOfWpdjuUWNte+icrtAO58I=",
      "url": "_framework/dotnet.native.87vtjjdetb.js"
    },
    {
      "hash": "sha256-cxtEpYwNaw5SZcxjGX5684Bzda4TyKmrK7bSsnG0NtA=",
      "url": "_framework/dotnet.native.befq3iek54.wasm"
    },
    {
      "hash": "sha256-2lZh9yO0fnzm3Xt7yV+Kox3DH3nK7L8hDhm84VT1xco=",
      "url": "_framework/dotnet.runtime.2tx45g8lli.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-69/HeVhf9D7EfBm80tzmnfAUAUHtui/ZW114VAa7IbM=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-40bsy5ZD/nd3ujmQGrK5Bm7uv7sWWVD7sSsYnMjtWD8=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-r+iDum4jijP2np52WwFnkwAtvsf5vg46dwDEl+CDZL4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-rgXh27bIoUwMbWXiM1GrISJJYqaSSgW0tLabxR76pxs=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-CfGp4x6EyX1jCWytU5Eqtna8Z1PcrOJwjEEEXrGiQCg=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-7oKWiOae9WVSZBYW2WJC+kp7H0A7ub1LDuu0aAsHKnI=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-VK7d6Or2uduKYXysDWKzSqRF4KKzG3NxsbUB5l6xGYc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-FhIxigcRfNM0P4W5XBo8d6hMKnnQHe95CD5PNSdT8pg=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-XHwOVjHGSkZaX1Av2q6My93E3o9tjp04sK4z3pJd7/c=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-e0Z07ryp1j8UeY00pm/7gDWavwOirnGmDRXuB/V3SEg=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-w+rp/gXUibEAdOrD/UXjat+tkn4DlimKqFnbc30Uez4=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
